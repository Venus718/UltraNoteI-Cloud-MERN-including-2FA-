// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import AddWallet from '../index';

describe('<AddWallet />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
