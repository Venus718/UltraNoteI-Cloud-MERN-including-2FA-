/**
 *
 * Asynchronously loads the component for AddWallet
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
