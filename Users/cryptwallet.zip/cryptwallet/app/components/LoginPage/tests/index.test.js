// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import LoginPage from '../index';

describe('<LoginPage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
