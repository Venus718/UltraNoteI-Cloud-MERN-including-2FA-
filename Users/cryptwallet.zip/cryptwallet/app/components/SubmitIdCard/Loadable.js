/**
 *
 * Asynchronously loads the component for SubmitIdCard
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
