/**
 *
 * Asynchronously loads the component for BuyCoinByQr
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
