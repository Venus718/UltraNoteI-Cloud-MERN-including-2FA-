/**
 *
 * Asynchronously loads the component for ConfirmCodePage
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
