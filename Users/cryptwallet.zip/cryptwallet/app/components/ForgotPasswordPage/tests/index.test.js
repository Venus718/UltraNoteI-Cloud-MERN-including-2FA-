// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import ForgotPasswordPage from '../index';

describe('<ForgotPasswordPage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
