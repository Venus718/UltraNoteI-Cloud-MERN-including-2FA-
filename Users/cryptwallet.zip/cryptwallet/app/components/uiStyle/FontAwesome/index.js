import React from 'react'

const FontAwesome = props => {
    return (
        <i className={`fa fa-${props.name}`}></i>
    )
}
export default FontAwesome