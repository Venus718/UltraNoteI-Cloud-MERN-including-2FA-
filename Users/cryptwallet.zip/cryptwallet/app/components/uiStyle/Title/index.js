import React from 'react'

const Title = (props) => {
    return (<title>{props.children}</title>)
}
export default Title