import { createGlobalStyle } from 'styled-components';
import '../docs/css/common.scss';
import '../docs/css/font-awesome.min.scss';

const GlobalStyle = createGlobalStyle`

`;

export default GlobalStyle;
