/*
 *
 * Settings constants
 *
 */

export const DEFAULT_ACTION = 'app/Settings/DEFAULT_ACTION';
