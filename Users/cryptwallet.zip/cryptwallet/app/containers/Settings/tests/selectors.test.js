// import { fromJS } from 'immutable';
// import { selectSettingsDomain } from '../selectors';

describe('selectSettingsDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
