// import { fromJS } from 'immutable';
// import { selectMyProfileDomain } from '../selectors';

describe('selectMyProfileDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
