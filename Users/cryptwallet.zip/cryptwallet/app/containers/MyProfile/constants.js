/*
 *
 * MyProfile constants
 *
 */

export const DEFAULT_ACTION = 'app/MyProfile/DEFAULT_ACTION';
