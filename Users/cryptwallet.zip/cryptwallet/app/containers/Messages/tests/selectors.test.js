// import { fromJS } from 'immutable';
// import { selectMessagesDomain } from '../selectors';

describe('selectMessagesDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
