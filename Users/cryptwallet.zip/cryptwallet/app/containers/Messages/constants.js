/*
 *
 * Messages constants
 *
 */

export const DEFAULT_ACTION = 'app/Messages/DEFAULT_ACTION';
