/*
 *
 * DashboardPage constants
 *
 */

export const DEFAULT_ACTION = 'app/DashboardPage/DEFAULT_ACTION';
