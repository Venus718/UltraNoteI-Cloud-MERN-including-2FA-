// import { fromJS } from 'immutable';
// import { selectDashboardPageDomain } from '../selectors';

describe('selectDashboardPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
