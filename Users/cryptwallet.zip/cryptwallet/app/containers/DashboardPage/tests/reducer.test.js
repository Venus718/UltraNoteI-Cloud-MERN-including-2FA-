import { fromJS } from 'immutable';
import dashboardPageReducer from '../reducer';

describe('dashboardPageReducer', () => {
  it('returns the initial state', () => {
    expect(dashboardPageReducer(undefined, {})).toEqual(fromJS({}));
  });
});
