/*
 *
 * IdVarification constants
 *
 */

export const DEFAULT_ACTION = 'app/IdVarification/DEFAULT_ACTION';
