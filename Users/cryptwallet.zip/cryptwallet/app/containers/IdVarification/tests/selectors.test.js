// import { fromJS } from 'immutable';
// import { selectIdVarificationDomain } from '../selectors';

describe('selectIdVarificationDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
