// import { fromJS } from 'immutable';
// import { selectPhoneVarificationDomain } from '../selectors';

describe('selectPhoneVarificationDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
