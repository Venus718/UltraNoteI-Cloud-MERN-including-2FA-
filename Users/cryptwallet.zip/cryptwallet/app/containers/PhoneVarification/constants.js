/*
 *
 * PhoneVarification constants
 *
 */

export const DEFAULT_ACTION = 'app/PhoneVarification/DEFAULT_ACTION';
