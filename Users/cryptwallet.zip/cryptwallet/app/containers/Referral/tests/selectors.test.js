// import { fromJS } from 'immutable';
// import { selectReferralDomain } from '../selectors';

describe('selectReferralDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
