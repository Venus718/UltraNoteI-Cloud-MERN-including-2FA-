/**
 *
 * Asynchronously loads the component for Referral
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
