/*
 *
 * Referral constants
 *
 */

export const DEFAULT_ACTION = 'app/Referral/DEFAULT_ACTION';
