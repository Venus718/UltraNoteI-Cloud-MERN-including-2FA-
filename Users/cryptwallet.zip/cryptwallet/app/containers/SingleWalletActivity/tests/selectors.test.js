// import { fromJS } from 'immutable';
// import { selectSingleWalletActivityDomain } from '../selectors';

describe('selectSingleWalletActivityDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
