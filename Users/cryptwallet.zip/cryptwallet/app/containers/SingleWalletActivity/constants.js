/*
 *
 * SingleWalletActivity constants
 *
 */

export const DEFAULT_ACTION = 'app/SingleWalletActivity/DEFAULT_ACTION';
