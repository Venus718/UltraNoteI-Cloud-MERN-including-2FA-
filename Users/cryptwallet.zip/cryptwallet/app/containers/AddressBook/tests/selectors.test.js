// import { fromJS } from 'immutable';
// import { selectAddressBookDomain } from '../selectors';

describe('selectAddressBookDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
