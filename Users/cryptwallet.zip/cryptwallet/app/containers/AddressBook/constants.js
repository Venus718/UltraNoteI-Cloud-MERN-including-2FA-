/*
 *
 * AddressBook constants
 *
 */

export const DEFAULT_ACTION = 'app/AddressBook/DEFAULT_ACTION';
