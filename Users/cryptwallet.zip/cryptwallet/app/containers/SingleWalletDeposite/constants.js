/*
 *
 * SingleWalletDeposite constants
 *
 */

export const DEFAULT_ACTION = 'app/SingleWalletDeposite/DEFAULT_ACTION';
