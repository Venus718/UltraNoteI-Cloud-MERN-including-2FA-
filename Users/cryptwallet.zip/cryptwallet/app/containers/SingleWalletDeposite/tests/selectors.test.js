// import { fromJS } from 'immutable';
// import { selectSingleWalletDepositeDomain } from '../selectors';

describe('selectSingleWalletDepositeDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
