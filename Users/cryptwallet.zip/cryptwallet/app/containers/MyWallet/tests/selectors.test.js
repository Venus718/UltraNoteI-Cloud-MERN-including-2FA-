// import { fromJS } from 'immutable';
// import { selectMyWalletDomain } from '../selectors';

describe('selectMyWalletDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
