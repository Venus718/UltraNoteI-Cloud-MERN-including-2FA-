/*
 *
 * MyWallet constants
 *
 */

export const DEFAULT_ACTION = 'app/MyWallet/DEFAULT_ACTION';
