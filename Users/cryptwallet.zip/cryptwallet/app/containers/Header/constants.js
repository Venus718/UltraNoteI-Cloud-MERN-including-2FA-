/*
 *
 * Header constants
 *
 */

export const DEFAULT_ACTION = 'app/Header/DEFAULT_ACTION';
