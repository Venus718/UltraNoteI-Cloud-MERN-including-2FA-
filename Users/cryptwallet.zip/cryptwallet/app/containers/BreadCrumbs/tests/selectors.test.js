// import { fromJS } from 'immutable';
// import { selectBreadCrumbsDomain } from '../selectors';

describe('selectBreadCrumbsDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
