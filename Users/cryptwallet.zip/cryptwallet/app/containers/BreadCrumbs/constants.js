/*
 *
 * BreadCrumbs constants
 *
 */

export const DEFAULT_ACTION = 'app/BreadCrumbs/DEFAULT_ACTION';
