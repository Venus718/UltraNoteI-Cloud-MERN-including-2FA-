/*
 *
 * ActivityLog constants
 *
 */

export const DEFAULT_ACTION = 'app/ActivityLog/DEFAULT_ACTION';
