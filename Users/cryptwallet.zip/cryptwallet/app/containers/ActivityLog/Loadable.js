/**
 *
 * Asynchronously loads the component for ActivityLog
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
