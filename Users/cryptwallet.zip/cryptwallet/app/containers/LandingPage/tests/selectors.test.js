// import { fromJS } from 'immutable';
// import { selectLandingPageDomain } from '../selectors';

describe('selectLandingPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
