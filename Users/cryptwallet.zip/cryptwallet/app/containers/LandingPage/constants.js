/*
 *
 * LandingPage constants
 *
 */

export const DEFAULT_ACTION = 'app/LandingPage/DEFAULT_ACTION';
