/*
 *
 * App constants
 *
 */

export const DEFAULT_ACTION = 'app/App/DEFAULT_ACTION';
