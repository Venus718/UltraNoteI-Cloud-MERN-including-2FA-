// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import { App } from '../index';

describe('<App />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
