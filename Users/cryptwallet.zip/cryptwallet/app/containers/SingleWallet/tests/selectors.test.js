// import { fromJS } from 'immutable';
// import { selectSingleWalletDomain } from '../selectors';

describe('selectSingleWalletDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
