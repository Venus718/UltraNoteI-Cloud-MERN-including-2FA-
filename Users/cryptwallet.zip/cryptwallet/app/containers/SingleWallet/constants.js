/*
 *
 * SingleWallet constants
 *
 */

export const DEFAULT_ACTION = 'app/SingleWallet/DEFAULT_ACTION';
