/**
 *
 * Asynchronously loads the component for RessetPassword
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
