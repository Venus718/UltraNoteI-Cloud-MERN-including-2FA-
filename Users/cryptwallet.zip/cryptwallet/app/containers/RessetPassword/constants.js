/*
 *
 * RessetPassword constants
 *
 */

export const DEFAULT_ACTION = 'app/RessetPassword/DEFAULT_ACTION';
