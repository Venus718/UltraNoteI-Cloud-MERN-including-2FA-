// import { fromJS } from 'immutable';
// import { selectRessetPasswordDomain } from '../selectors';

describe('selectRessetPasswordDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
