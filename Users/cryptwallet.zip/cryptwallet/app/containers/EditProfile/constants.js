/*
 *
 * EditProfile constants
 *
 */

export const DEFAULT_ACTION = 'app/EditProfile/DEFAULT_ACTION';
