// import { fromJS } from 'immutable';
// import { selectEditProfileDomain } from '../selectors';

describe('selectEditProfileDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
