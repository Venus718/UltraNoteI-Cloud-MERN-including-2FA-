/*
 *
 * SingleWalletWithdraw constants
 *
 */

export const DEFAULT_ACTION = 'app/SingleWalletWithdraw/DEFAULT_ACTION';
