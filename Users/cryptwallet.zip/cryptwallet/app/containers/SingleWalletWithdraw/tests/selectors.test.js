// import { fromJS } from 'immutable';
// import { selectSingleWalletWithdrawDomain } from '../selectors';

describe('selectSingleWalletWithdrawDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
