/*
 *
 * Billing constants
 *
 */

export const DEFAULT_ACTION = 'app/Billing/DEFAULT_ACTION';
