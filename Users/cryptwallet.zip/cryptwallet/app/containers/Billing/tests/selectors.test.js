// import { fromJS } from 'immutable';
// import { selectBillingDomain } from '../selectors';

describe('selectBillingDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
