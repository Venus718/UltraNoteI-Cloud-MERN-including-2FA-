// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import { Billing } from '../index';

describe('<Billing />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
