/*
 *
 * BuyCoin constants
 *
 */

export const DEFAULT_ACTION = 'app/BuyCoin/DEFAULT_ACTION';
