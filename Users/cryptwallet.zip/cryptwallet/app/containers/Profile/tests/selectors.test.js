// import { fromJS } from 'immutable';
// import { selectProfileDomain } from '../selectors';

describe('selectProfileDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
