/*
 *
 * Profile constants
 *
 */

export const DEFAULT_ACTION = 'app/Profile/DEFAULT_ACTION';
